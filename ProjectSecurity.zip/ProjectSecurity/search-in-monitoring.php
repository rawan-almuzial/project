<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "securitydb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all data for initial display
$result = $conn->query("SELECT * FROM monitoringreport");
$data = $result->fetch_all(MYSQLI_ASSOC);

// Handle search request
if (isset($_POST['search'])) {
    $searchTerm = $conn->real_escape_string($_POST['search']);
    $query = "SELECT * FROM monitoring_report WHERE 
               
              Region LIKE '%$searchTerm%' OR 
              Office LIKE '%$searchTerm%' OR 
              Time LIKE '%$searchTerm%' OR 
              GregorianCalendarDate LIKE '%$searchTerm%' OR 
              HijriCalendarDate LIKE '%$searchTerm%' OR 
              ObserversName LIKE '%$searchTerm%' OR 
              Day LIKE '%$searchTerm%' OR 
              Notes LIKE '%$searchTerm%'";
    $result = $conn->query($query);
    $data = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>البحث في تقرير المراقبة</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: white;
            margin: 0;
            display: flex;
            flex-direction: column;
            height: 100vh;
            box-sizing: border-box;
        }
        .navbar {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgba(169, 169, 169, 0.5);
            width: 100%;
            padding: 10px 20px;
        }
        .search-box {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }
        .search-box input {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 300px;
        }
        .search-box button {
            padding: 10px;
            border: none;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        .search-box button:hover {
            background-color: #0056b3;
        }
        .results {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<div class="navbar">
    <h1>البحث في تقرير المراقبة</h1>
</div>

<div class="search-box">
    <form id="searchForm" method="POST">
        <input type="text" name="search" placeholder="ابحث في تقرير المراقبة" required>
        <button type="submit">بحث</button>
    </form>
</div>

<div class="results">
    <table>
        <thead>
            <tr>
                <th>UserID</th>
                <th>Region</th>
                <th>Office</th>
                <th>Time</th>
                <th>GregorianCalendarDate</th>
                <th>HijriCalendarDate</th>
                <th>ObserversName</th>
                <th>Day</th>
                <th>Noets</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $row): ?>
                <tr>
                    
                    <td><?php echo htmlspecialchars($row['Region']); ?></td>
                    <td><?php echo htmlspecialchars($row['Office']); ?></td>
                    <td><?php echo htmlspecialchars($row['Time']); ?></td>
                    <td><?php echo htmlspecialchars($row['GregorianCalendarDate']); ?></td>
                    <td><?php echo htmlspecialchars($row['HijriCalendarDate']); ?></td>
                    <td><?php echo htmlspecialchars($row['ObserversName']); ?></td>
                    <td><?php echo htmlspecialchars($row['Day']); ?></td>
                    <td><?php echo htmlspecialchars($row['Notes']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#searchForm').submit(function(event) {
            event.preventDefault();
            $.ajax({
                type: 'POST',
                url: 'search.php',
                data: $(this).serialize(),
                success: function(response) {
                    $('.results').html(response);
                }
            });
        });
    });
</script>

</body>
</html>
