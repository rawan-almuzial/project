
<?php 
	session_start();
	try

{
	$connection=mysqli_connect("localhost","root","","securitydb");
	
}

catch(
PDOException $e){
	
echo "error".$e->getMessage();}
							
// 							if(!isset($_SESSION['user'])){
	
// 	header('location:loginw.html');
// 	exit();
// }
//           else{ echo $_SESSION['user']['name'];}?>