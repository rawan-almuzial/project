<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "securitydb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $id = $conn->real_escape_string($_POST['id']);
    $result = $conn->query("SELECT * FROM monitoringreport WHERE id = '$id'");
    $data = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $id = $conn->real_escape_string($_POST['id']);
    $region = $conn->real_escape_string($_POST['region']);
    $office = $conn->real_escape_string($_POST['office']);
    $time = $conn->real_escape_string($_POST['time']);
    $gregorianDate = $conn->real_escape_string($_POST['gregorianDate']);
    $hijriDate = $conn->real_escape_string($_POST['hijriDate']);
    $observersName = $conn->real_escape_string($_POST['observersName']);
    $day = $conn->real_escape_string($_POST['day']);
    $notes = $conn->real_escape_string($_POST['notes']);

    $sql = "UPDATE monitoringreport SET 
                Region='$region', 
                Office='$office', 
                Time='$time', 
                GregorianCalendarDate='$gregorianDate', 
                HijriCalendarDate='$hijriDate', 
                ObserversName='$observersName', 
                Day='$day', 
                Notes='$notes' 
            WHERE id='$id'";
 /* header('search_monitoring.php'); // Redirect to your main page
    if ($conn->query($sql) === TRUE) {
        header('search_monitoring.php'); // Redirect to your main page
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }*/



    if ($conn->query($sql) === TRUE) {
       echo "<script>
                alert('Data has been updated successfully');
                window.location.href = 'search_monitoring.php';
              </script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    // Close statement and connection
   
    $conn->close();

}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        input[type="time"]:focus {
            border-color: #007BFF;
            outline: none;
        }

        button {
            width: 45%;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        .form-group {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <h1>Edit Report</h1>
        <form method="POST">
                <input type="hidden" name="id" value="<?php echo isset($data['id']) ? htmlspecialchars($data['id']) : ''; ?>">
                
                <div class="form-group">
                    <label for="region">Region:</label>
                    <input type="text" name="region" id="region" class="form-control" value="<?php echo isset($data['Region']) ? htmlspecialchars($data['Region']) : ''; ?>" required>
                    
                </div>

                <div class="form-group">
                    <label for="office">Office:</label>
                    <input type="text" name="office" id="office" class="form-control" value="<?php echo isset($data['Office']) ? htmlspecialchars($data['Office']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="time">Time:</label>
                    <input type="time" name="time" id="time" class="form-control" value="<?php echo isset($data['Time']) ? htmlspecialchars($data['Time']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="gregorianDate">Gregorian Date:</label>
                    <input type="date" name="gregorianDate" id="gregorianDate" class="form-control" value="<?php echo isset($data['GregorianCalendarDate']) ? htmlspecialchars($data['GregorianCalendarDate']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="hijriDate">Hijri Date:</label>
                    <input type="text" name="hijriDate" id="hijriDate" class="form-control" value="<?php echo isset($data['HijriCalendarDate']) ? htmlspecialchars($data['HijriCalendarDate']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="observersName">Observers Name:</label>
                    <input type="text" name="observersName" id="observersName" class="form-control" value="<?php echo isset($data['ObserversName']) ? htmlspecialchars($data['ObserversName']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="day">Day:</label>
                    <input type="text" name="day" id="day" class="form-control" value="<?php echo isset($data['Day']) ? htmlspecialchars($data['Day']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="notes">Notes:</label>
                    <input type="text" name="notes" id="notes" class="form-control" value="<?php echo isset($data['Notes']) ? htmlspecialchars($data['Notes']) : ''; ?>" required>
                </div>
                <button type="submit" name="update" >Update</button>
                <button type="cancel" name="CANCEL" > <a href="search_monitoring.php" >CANCEL</a></button>
              
            </form>
        </div>
    </div>
</div>

<footer>
</footer>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>
</body>
</html>