<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "securitydb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userName = $_POST['userName'];
    $password = $_POST['password'];

    // Check if fields are filled
    if (empty($userName) || empty($password)) {
        echo "Username and password are required.";
        exit;
    }

    // Prepare and execute the SQL query
    $stmt = $pdo->prepare("SELECT * FROM user WHERE userName = :userName");
    $stmt->execute(['userName' => $userName]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Verify password (assuming plain text; ideally, you should hash it with password_hash)
        if ($password === $user['password']) { // replace with password_verify if hashed
            // Login successful
            $_SESSION['userName'] = $user['userName'];
      
            
            echo "Welcome, " . htmlspecialchars($user['userName']) . "!";
            // Redirect based on role (optional)
            if ($user['role'] === 'admin') {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: user_dashboard.php");
            }
            exit;
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with that username.";
    }
}
?>