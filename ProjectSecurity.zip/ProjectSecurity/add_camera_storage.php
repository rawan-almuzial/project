<?php
// Database connection parameters
$servername = "localhost"; // Update with your server name
$username = "root"; // Update with your database username
$password = ""; // Update with your database password
$dbname = "securitydb"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize input
    $Region = $_POST['Region'];
    $Office = $_POST['Office'];
    $TimeOfNoteEntry = $_POST['TimeOfNoteEntry'];
    $GregorianCalendarDateOfEntry = $_POST['GregorianCalendarDateOfEntry'];
    $HijriCalendarDateOfEntry = $_POST['HijriCalendarDateOfEntry'];
    $Day = $_POST['Day'];
    $ObserversName = $_POST['ObserversName'];
    $StartOfStorage = $_POST['StartOfStorage'];
    $AvailableStorageDuration = $_POST['AvailableStorageDuration'];
    $Notes = $_POST['Notes'];



    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO camera_storage_report (  Region, Office, TimeOfNoteEntry, GregorianCalendarDateOfEntry, HijriCalendarDateOfEntry, Day, ObserversName, StartOfStorage, AvailableStorageDuration,Notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?)");
    
    // Bind parameters ('ssssssssssss' indicates all parameters are strings)
    $stmt->bind_param('ssssssssss', $Region, $Office, $TimeOfNoteEntry, $GregorianCalendarDateOfEntry, $HijriCalendarDateOfEntry, $Day, $ObserversName, $StartOfStorage, $AvailableStorageDuration,$Notes );

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script>
                alert('New record created successfully');
                window.location.href = 'تخزين.html'; // Redirect to your desired page
              </script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
