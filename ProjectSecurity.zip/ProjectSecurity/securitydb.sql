-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2024 at 12:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `securitydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `camera_malfuntion_report`
--

CREATE TABLE `camera_malfuntion_report` (
  `id` int(11) NOT NULL,
  `UserID` varchar(50) DEFAULT NULL,
  `CameraID` int(11) DEFAULT NULL,
  `CameraStatus` varchar(50) DEFAULT NULL,
  `MalfunctionType` varchar(50) DEFAULT NULL,
  `Region` varchar(20) DEFAULT NULL,
  `Office` varchar(20) DEFAULT NULL,
  `GregorianCalendarDateOfEntry` date DEFAULT NULL,
  `HijriCalendarDateOfEntry` date DEFAULT NULL,
  `Day` varchar(20) DEFAULT NULL,
  `Notes` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `camera_malfuntion_report`
--

INSERT INTO `camera_malfuntion_report` (`id`, `UserID`, `CameraID`, `CameraStatus`, `MalfunctionType`, `Region`, `Office`, `GregorianCalendarDateOfEntry`, `HijriCalendarDateOfEntry`, `Day`, `Notes`) VALUES
(10, '', 2, '11', 'wewwrr', 'تبوك', '212', '2024-10-20', '2024-10-09', 'الأحد', '22666');

-- --------------------------------------------------------

--
-- Table structure for table `camera_storage_report`
--

CREATE TABLE `camera_storage_report` (
  `id` int(11) NOT NULL,
  `UserID` int(20) DEFAULT NULL,
  `CameraID` int(20) DEFAULT NULL,
  `Region` varchar(20) DEFAULT NULL,
  `Office` varchar(20) DEFAULT NULL,
  `TimeOfNoteEntry` varchar(50) DEFAULT NULL,
  `GregorianCalendarDateOfEntry` date DEFAULT NULL,
  `HijriCalendarDateOfEntry` date DEFAULT NULL,
  `Day` varchar(20) DEFAULT NULL,
  `ObserversName` varchar(50) DEFAULT NULL,
  `StartOfStorage` varchar(50) DEFAULT NULL,
  `AvailableStorageDuration` varchar(50) DEFAULT NULL,
  `Notes` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `camera_storage_report`
--

INSERT INTO `camera_storage_report` (`id`, `UserID`, `CameraID`, `Region`, `Office`, `TimeOfNoteEntry`, `GregorianCalendarDateOfEntry`, `HijriCalendarDateOfEntry`, `Day`, `ObserversName`, `StartOfStorage`, `AvailableStorageDuration`, `Notes`) VALUES
(7, NULL, NULL, 'الدمام', '212', '05:55', '2024-10-21', '2024-10-01', 'الاثنين', '22', 'يب', '2', 'fsf');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `LoginTime` int(11) DEFAULT NULL,
  `IPAddress` int(30) DEFAULT NULL,
  `Deviceinfo` varchar(50) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `LoginID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `monitoringreport`
--

CREATE TABLE `monitoringreport` (
  `id` int(11) UNSIGNED NOT NULL,
  `UserID` int(50) DEFAULT NULL,
  `Region` varchar(50) DEFAULT NULL,
  `Office` varchar(50) DEFAULT NULL,
  `Time` int(11) DEFAULT NULL,
  `GregorianCalendarDate` date DEFAULT NULL,
  `HijriCalendarDate` date DEFAULT NULL,
  `ObserversName` varchar(50) DEFAULT NULL,
  `Day` varchar(50) DEFAULT NULL,
  `Notes` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `monitoringreport`
--

INSERT INTO `monitoringreport` (`id`, `UserID`, `Region`, `Office`, `Time`, `GregorianCalendarDate`, `HijriCalendarDate`, `ObserversName`, `Day`, `Notes`) VALUES
(9, NULL, 'تبوك', '545', 1222, '2024-09-30', '2024-10-21', 'Sam', 'الجمعة', '233'),
(10, NULL, 'الرياض', 'sfdf', 19, '2024-10-27', '2024-10-27', 'sds', 'الاثنين', 'sff'),
(12, NULL, 'تبوك', '545', 1222, '2024-09-30', '2024-10-21', 'Sam', 'الجمعة', '233'),
(13, NULL, 'الرياض', 'sfdf', 19, '2024-10-27', '2024-10-27', 'sds', 'الاثنين', 'sff'),
(14, NULL, 'الرياض', '2', 20, '2024-10-21', '2024-10-28', 'DAD', 'الاثنين', 'ققق');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(11) NOT NULL,
  `userName` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL COMMENT 'Role IN( ‘admin’ , ‘user’))'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `userName`, `password`, `role`) VALUES
(0, 'a', '123', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `camera_malfuntion_report`
--
ALTER TABLE `camera_malfuntion_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `camera_storage_report`
--
ALTER TABLE `camera_storage_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`LoginID`),
  ADD KEY `FK-Login` (`userID`);

--
-- Indexes for table `monitoringreport`
--
ALTER TABLE `monitoringreport`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `camera_malfuntion_report`
--
ALTER TABLE `camera_malfuntion_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `camera_storage_report`
--
ALTER TABLE `camera_storage_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `monitoringreport`
--
ALTER TABLE `monitoringreport`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
