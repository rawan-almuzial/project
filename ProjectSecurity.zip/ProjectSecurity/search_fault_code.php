<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "securitydb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Delete Request
if (isset($_POST['Delete'])) {
    $idToDelete = $conn->real_escape_string($_POST['id']);
    $deleteQuery = "DELETE FROM camera_malfuntion_report WHERE id='$idToDelete'";
    if ($conn->query($deleteQuery) === TRUE) {
        echo "<script>
        alert('Record deleted successfully');
        window.location.href=window.location.href;
      </script>";
exit;  
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}


// Handle Search Request
if (isset($_POST['search'])) {
    $searchTerm = $conn->real_escape_string($_POST['search']);
    $query = "SELECT * FROM camera_malfuntion_report WHERE 
    Region LIKE '%$searchTerm%' OR 
        UserID LIKE '%$searchTerm%' OR 
         CameraStatus LIKE '%$searchTerm%' OR 
    Office LIKE '%$searchTerm%' OR 
    MalfunctionType LIKE '%$searchTerm%' OR 
    GregorianCalendarDateOfEntry LIKE '%$searchTerm%' OR 
    HijriCalendarDateOfEntry LIKE '%$searchTerm%' OR 
    Day LIKE '%$searchTerm%' OR 
    CameraID LIKE '%$searchTerm%' OR 
     Notes LIKE '%$searchTerm%'";

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        echo "<table>
                <thead>
             <tr>
                <th>رقم الشاشة   </th>
                <th>المنطقة</th>
                <th>المكتب</th>
                <th>اليوم   </th>
                <th>تاريخ الإدخال ميلادي  </th>
                <th>تاريخ الإدخال الهجري  </th>
                <th>حالة الكاميرا  </th>
                <th>طرق المعالجة  </th>
                <th>الملاحظة</th>
             
            </tr>
                </thead>
                <tbody>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>" . htmlspecialchars($row['CameraID']) . "</td>
                    <td>" . htmlspecialchars($row['Region']) . "</td>
                    <td>" . htmlspecialchars($row['Office']) . "</td>
                     <td>" . htmlspecialchars($row['Day']) . "</td>
                    <td>" . htmlspecialchars($row['GregorianCalendarDateOfEntry']) . "</td>
                    <td>" . htmlspecialchars($row['HijriCalendarDateOfEntry']) . "</td>
                    <td>" . htmlspecialchars($row['CameraStatus']) . "</td>
                   <td>" . htmlspecialchars($row['MalfunctionType']) . "</td>
                   <td>" . htmlspecialchars($row['Notes']) . "</td>
                   </tr>";


                     }

        echo "</tbody></table>";
    } else {
        echo "<p>لا توجد نتائج مطابقة.</p>";
    }
}

$conn->close();
?>
