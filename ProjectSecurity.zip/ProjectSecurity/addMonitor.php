<?php
// Database connection parameters
$servername = "localhost"; // Update with your server name
$username = "root"; // Update with your database username
$password = ""; // Update with your database password
$dbname = "securitydb"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $region = $_POST['region'];
    $office = $_POST['office'];
    $time = $_POST['time'];
    $GregorianCalendarDate = $_POST['gregorianDate'];
    $HijriCalendarDate = $_POST['hijriDate'];
    $observersName = $_POST['observersName'];
    $day = $_POST['day'];
    $Notes = $_POST['notes'];

    // Prepare and bind
    // Use 'ssssssss' for all string types
    $stmt = $conn->prepare("INSERT INTO monitoringreport (Region, Office, Time, GregorianCalendarDate, HijriCalendarDate, ObserversName, Day, Notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    // 'ssssssss' indicates all parameters are strings
    $stmt->bind_param('ssssssss', $region, $office, $time, $GregorianCalendarDate, $HijriCalendarDate, $observersName, $day, $Notes);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script>
                alert('New record created successfully');
                window.location.href = 'مراقبه.html';
              </script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
