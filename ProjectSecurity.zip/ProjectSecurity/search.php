<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "securitydb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Delete Request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    $id = $conn->real_escape_string($_POST['id']);
    $delete_sql = "DELETE FROM monitoringreport WHERE id = '$id'";

    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>
                alert('Record deleted successfully');
                window.location.href = 'search_monitoring.php';
              </script>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Handle Search Request
if (isset($_POST['search'])) {
    $searchTerm = $conn->real_escape_string($_POST['search']);
    $query = "SELECT * FROM monitoringreport WHERE 
              UserID LIKE '%$searchTerm%' OR 
              Region LIKE '%$searchTerm%' OR 
              Office LIKE '%$searchTerm%' OR 
              Time LIKE '%$searchTerm%' OR 
              GregorianCalendarDate LIKE '%$searchTerm%' OR 
              HijriCalendarDate LIKE '%$searchTerm%' OR 
              ObserversName LIKE '%$searchTerm%' OR 
              Day LIKE '%$searchTerm%' OR 
              Notes LIKE '%$searchTerm%'";

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        echo "<table>
                <thead>
                    <tr>
                          <th>المنطقة</th>
                <th>المكتب</th>
                <th>الوقت</th>
                <th>تاريخ الإدخال ميلادي  </th>
                <th>تاريخ الإدخال الهجري  </th>
                <th>اسم المراقب  </th>
                <th>اليوم   </th>
                <th>الملاحظة</th>
                  
                    </tr>
                </thead>
                <tbody>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>
     
                 
                    <td>" . htmlspecialchars($row['Region']) . "</td>
                    <td>" . htmlspecialchars($row['Office']) . "</td>
                    <td>" . htmlspecialchars($row['Time']) . "</td>
                    <td>" . htmlspecialchars($row['GregorianCalendarDate']) . "</td>
                    <td>" . htmlspecialchars($row['HijriCalendarDate']) . "</td>
                    <td>" . htmlspecialchars($row['ObserversName']) . "</td>
                    <td>" . htmlspecialchars($row['Day']) . "</td>
                    <td>" . htmlspecialchars($row['Notes']) . "</td>

                   
                  </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<p>لا توجد نتائج مطابقة.</p>";
    }
}

$conn->close();
?>
