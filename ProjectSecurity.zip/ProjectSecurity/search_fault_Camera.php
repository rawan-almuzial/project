<?php
// Database connection parameters
$servername = "localhost"; // Update with your server name
$username = "root"; // Update with your database username
$password = ""; // Update with your database password
$dbname = "securitydb"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$result = $conn->query("SELECT * FROM camera_malfuntion_report");
$data = $result->fetch_all(MYSQLI_ASSOC);
// Check if form is submitted for search
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    // Retrieve and sanitize search input
    $searchTerm = $conn->real_escape_string($_POST['search']);
    
    // Query to search records based on provided term
    $query = "SELECT * FROM camera_malfuntion_report WHERE 
              Region LIKE '%$searchTerm%' OR 
                  UserID LIKE '%$searchTerm%' OR 
                   CameraStatus LIKE '%$searchTerm%' OR 
              Office LIKE '%$searchTerm%' OR 
              MalfunctionType LIKE '%$searchTerm%' OR 
              GregorianCalendarDateOfEntry LIKE '%$searchTerm%' OR 
              HijriCalendarDateOfEntry LIKE '%$searchTerm%' OR 
              Day LIKE '%$searchTerm%' OR 
              CameraID LIKE '%$searchTerm%' OR 
               Notes LIKE '%$searchTerm%'";
               

    $result = $conn->query($query);
     $data = $result->fetch_all(MYSQLI_ASSOC);
    }
    // Handle delete request
if (isset($_POST['Delete'])) {
    $idToDelete = $conn->real_escape_string($_POST['id']);
    $deleteQuery = "DELETE FROM camera_malfuntion_report WHERE id='$idToDelete'";
    if ($conn->query($deleteQuery) === TRUE) {
        echo "<script>
        alert('Record deleted successfully');
        window.location.href=window.location.href;
      </script>";
exit;  
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}


?>

<title>تعديل او الحذف من تقرير أعطال الكاميرات</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
    body {
            font-family: Arial, sans-serif;
            background-color: white;
            margin: 0;
            display: flex;
            flex-direction: column;
            height: 100vh;
            box-sizing: border-box;
        }
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }

        .sidebar {
            width: 200px;
            background: linear-gradient(to bottom right, #283750, #3f97b1);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
            min-height: 100vh;
            position: fixed;
            right: 0;
            z-index: 1;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            margin: 10px 0;
            transition: color 0.3s;
        }

        .sidebar a:hover {
            color: #f0f0f0;
        }

        .logout-button {
        position: absolute;
        top: 0;
        left: 20px;
        background-color: #8f8f8f;
        color: rgb(255, 255, 255);
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        display: flex;
        align-items: center;
    }
    .navbar img.logo1 {
    width: 170px;
    height: 60px;
    }

        .navbar {
            display: flex;
            align-items: center;
            background-color: rgba(169, 169, 169, 0.5);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 130%;
            max-width: 1500px;
            padding: 10px 20px;
            border-radius: 15px;
            margin: 20px auto;
            position: relative;
        }

  

        .navbar ul {
            list-style: none;
            display: flex;
            padding: 0;
            margin: 0;
        }

        .navbar li {
            margin: 0 20px;
        }

        .navbar a {
            text-decoration: none;
            color: #000000;
            padding: 7px 16px;
            border-radius: 5px;
            transition: background-color 0.3s, box-shadow 0.3s;
            font-size: 22px;
        }

        .navbar a:hover {
            background-color: rgba(169, 169, 169, 0.7);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .search-box button {
            padding: 10px;
            border: none;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        .search-box button:hover {
            background-color: #0056b3;
        }
        .search-box button {
            padding: 10px;
            border: none;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        .search-box button:hover {
            background-color: #0056b3;
        }
   
    /* Table container for responsive styling */
 




    table {
        width: 85%;
        border-collapse: collapse;
        overflow: hidden;
        border-radius: 8px;
    }
    .results1 {
    margin-top: 20px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
    border-radius: 8px;
    background-color: #ffffff;
    float: left; /* Maintains left alignment */
    clear: both; /* Ensures it starts on a new line if needed */
    width: 85%; /* To balance space with the sidebar */
    margin-left: 10px;
    }

    th {
        background-color: #283750;
        color: #ffffff;
        padding: 12px 8px;
        font-size: 16px;
        text-align: center;
        font-weight: bold;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    td {
        padding: 10px;
        font-size: 15px;
        color: #333333;
        text-align: center;
        border-bottom: 1px solid #dddddd;
        transition: background-color 0.2s;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:nth-child(odd) {
        background-color: #ffffff;
    }

    tr:hover {
        background-color: #f1f5ff;
    }

    button[name="Edit"],
    button[name="delete"] {
        padding: 6px 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        transition: background-color 0.3s;
    }

    button[name="Edit"] {
        background-color: #007bff;
        color: white;
    }

    button[name="Edit"]:hover {
        background-color: #0056b3;
    }

    button[name="delete"] {
        background-color: #dc3545;
        color: white;
    }

    button[name="delete"]:hover {
        background-color: #c82333;
    }  

    /* Table header styling */
    th {
        background-color: #283750; /* Dark blue header */
        color: #ffffff;
        padding: 12px 8px;
        font-size: 16px;
        text-align: center;
        font-weight: bold;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    /* Table cell styling */
    td {
        padding: 10px;
        font-size: 15px;
        color: #333333;
        text-align: center;
        border-bottom: 1px solid #dddddd;
        transition: background-color 0.2s;
    }

    /* Alternating row colors */
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:nth-child(odd) {
        background-color: #ffffff;
    }

    /* Hover effect for table rows */
    tr:hover {
        background-color: #f1f5ff;
    }

    /* Style for Edit and Delete buttons */
    button[name="Edit"] {
        background-color: #007bff;
        color: white;
        padding: 6px 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        transition: background-color 0.3s;
    }

    button[name="Edit"]:hover {
        background-color: #0056b3;
    }

    button[name="delete"] {
        background-color: #dc3545;
        color: white;
        padding: 6px 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        transition: background-color 0.3s;
    }

    button[name="delete"]:hover {
        background-color: #c82333;
    }
    h1 {
        font-size: 28px;
        font-weight: bold;
        text-align: center;
        color: #283750; /* Dark blue color to match the sidebar */
        background: linear-gradient(45deg, #3f97b1, #283750);
        color: white;
        padding: 15px 30px;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        max-width: 80%;
        margin: 20px auto;
        letter-spacing: 0.05em;
        text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
    }
</style>

<script>
        function logout() {
            window.location.href = 'Login.html';
        }

    </script>
    
</head>

<div>
    <button class="logout-button" onclick="logout()">
        تسجيل الخروج <img src="img-html/igacont.jpeg" style="position: relative;" alt="الشعار" style="width: 25px; height: 25px; position: absolute; left: 70px; top: -160px;" alt="Logout Icon">
    </button>
   </div>
<div class="main-content">
   
    
    <div class="navbar">
        
        <ul>
            <li><a href="Dashboard.html">التقارير</a></li>
            <li><a href="البحث.html">البحث</a></li>
            <li><a href="أعطال.html">تقرير أعطال الكاميرات</a></li>
            <li><a href="تخزين.html">تقرير تخزين الكاميرات</a></li>
            <li><a href="مراقبه.html">تقرير المراقبة</a></li>
            <li><a href="Home.html">الرئيسية</a></li>
        </ul>
    </div>
    <img src="img-html/الشعاررر.jpg" alt="الشعار" class="logo1">

<h1>   تعديل  او الحذف من  تقرير أعطال الكاميرات    </h1>


<div class="search-box">
    <form id="searchForm" method="POST">
        <input type="text" name="search" placeholder="ابحث في تقرير المراقبة" required>
        <button type="submit">بحث</button>
    </form>
</div>

<div class="results1">
    <table>
        <thead>
            <tr>
            <th>Edit</th>  
            <th>Delete</th>
            <th>رقم الشاشة   </th>
                <th>المنطقة</th>
                <th>المكتب</th>
                <th>الوقت</th>
                <th>تاريخ الإدخال ميلادي  </th>
                <th>تاريخ الإدخال الهجري  </th>
                <th>حالة الكاميرا  </th>
                <th>طرق المعالجة  </th>
                <th>الملاحظة</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $row): ?>
                <tr>
                <td>
                <form method="POST" action="EditFault.php" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>"> <!-- Assuming 'id' is the primary key -->
                    <button type="submit" name="Edit">Edit</button>
                </form>
               
            </td>
            <td>
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="delete" onclick="return confirm('Are you sure you want to delete this record?')">Delete</button>
                            </form>
                        </td>
               
                     <td><?php echo htmlspecialchars($row['CameraID']); ?></td>
                    <td><?php echo htmlspecialchars($row['Region']); ?></td>
                    <td><?php echo htmlspecialchars($row['Office']); ?></td>
                    <td><?php echo htmlspecialchars($row['Day']); ?></td>
                    <td><?php echo htmlspecialchars($row['GregorianCalendarDateOfEntry']); ?></td>
                    <td><?php echo htmlspecialchars($row['HijriCalendarDateOfEntry']); ?></td>
                    <td><?php echo htmlspecialchars($row['CameraStatus']); ?></td>
                    <td><?php echo htmlspecialchars($row['MalfunctionType']); ?></td>
                     <td><?php echo htmlspecialchars($row['Notes']); ?></td>
                   
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>


<div class="sidebar"> </div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/ar.js"></script>
