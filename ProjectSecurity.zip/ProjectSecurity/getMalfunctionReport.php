<?php
// Database connection parameters
$servername = "localhost"; // Update with your server name
$username = "root"; // Update with your database username
$password = ""; // Update with your database password
$dbname = "securitydb"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8"); // Set UTF-8 encoding
$year = isset($_GET['year']) ? intval($_GET['year']) : date("Y");

$stmt = $conn->prepare("
    SELECT COUNT(id) AS m_count, MONTH(GregorianCalendarDate) AS month 
    FROM `monitoringreport`
    WHERE YEAR(GregorianCalendarDate) = :year
    GROUP BY month
");
$stmt->execute(['year' => $year]);

$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($data);
?>